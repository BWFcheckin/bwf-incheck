/*
 * Beveiligde Planyo-doorvoer voor het BWF-dashboard.
 * Secrets: PLANYO_API_KEY, SUPABASE_URL en SUPABASE_ANON_KEY.
 */

const PLANYO_API = "https://www.planyo.com/rest/";

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "private, max-age=60",
      "access-control-allow-origin": "*",
      "access-control-allow-headers": "authorization, content-type",
      "access-control-allow-methods": "GET, OPTIONS"
    }
  });
}

async function isIngelogd(request: Request) {
  const auth = request.headers.get("authorization") || "";
  const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY") || "";
  if (!auth.startsWith("Bearer ") || !supabaseUrl || !anonKey) return false;
  const r = await fetch(`${supabaseUrl}/auth/v1/user`, {
    headers: { authorization: auth, apikey: anonKey }
  });
  return r.ok;
}

function datumTijd(value: string | null, fallback: Date) {
  const raw = (value || "").slice(0, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(raw)
    ? `${raw} 00:00`
    : `${fallback.toISOString().slice(0, 10)} 00:00`;
}

function telefoon(r: Record<string, unknown>) {
  const mobiel = String(r.mobile_number || "");
  const mobielLand = String(r.mobile_country_code || "");
  const vast = String(r.phone || r.phone_number || "");
  const vastLand = String(r.phone_country_code || "");
  if (mobiel) return (mobielLand ? `+${mobielLand}` : "") + mobiel;
  return (vastLand ? `+${vastLand}` : "") + vast;
}

function eventVanReservering(r: Record<string, unknown>) {
  const voornaam = String(r.first_name || "").trim();
  const achternaam = String(r.last_name || "").trim();
  const naam = `${voornaam} ${achternaam}`.trim();
  const status = Number(r.status || 0);
  return {
    id: String(r.reservation_id || ""),
    nummer: String(r.reservation_id || ""),
    start: String(r.start_time || ""),
    eind: String(r.end_time || ""),
    suite: String(r.name || ""),
    gast: naam,
    voornaam,
    achternaam,
    email: String(r.email || ""),
    telefoon: telefoon(r),
    adres: [r.address, r.zip, r.city, r.country].filter(Boolean).join(", "),
    personen: String(r.quantity || ""),
    totaal: Number(r.total_price || 0),
    betaald: Number(r.amount_paid || 0),
    status,
    statusLabel: status === 4 ? "Bevestigd" : status === 8 || status === 16 ? "Geannuleerd" : "In behandeling",
    soort: status === 8 || status === 16 ? "geannuleerd" : "reservering",
    bron: "Planyo",
    titel: naam || `Reservering ${r.reservation_id || ""}`,
    omschrijving: String(r.admin_notes || r.user_notes || ""),
    assignment: String(r.unit_assignment || "")
  };
}

async function planyo(method: string, extra: Record<string, string>) {
  const apiKey = Deno.env.get("PLANYO_API_KEY") || "";
  if (!apiKey) throw new Error("PLANYO_API_KEY is nog niet ingesteld.");
  const params = new URLSearchParams({ method, api_key: apiKey, language: "NL", ...extra });
  const r = await fetch(`${PLANYO_API}?${params.toString()}`, {
    headers: { accept: "application/json" }
  });
  const text = await r.text();
  let data: Record<string, unknown>;
  try { data = JSON.parse(text); }
  catch { throw new Error("Planyo gaf geen geldig antwoord."); }
  if (!r.ok || data.response_code === -1 || data.error) {
    throw new Error(String(data.error || data.response_message || `Planyo HTTP ${r.status}`));
  }
  return data;
}

Deno.serve(async (request) => {
  if (request.method === "OPTIONS") return json({ ok: true });
  if (request.method !== "GET") return json({ error: "Alleen GET is toegestaan." }, 405);
  if (!(await isIngelogd(request))) return json({ error: "Niet ingelogd." }, 401);

  const url = new URL(request.url);
  const action = url.searchParams.get("action") || "reservations";

  try {
    if (action === "customers") {
      const page = String(Math.max(0, Number(url.searchParams.get("page") || 0)));
      const data = await planyo("list_users", { page, page_size: "1000", detail_level: "1" });
      const users = Array.isArray(data.users) ? data.users : [];
      return json({ customers: users, page: Number(page), source: "Planyo" });
    }

    const nu = new Date();
    const later = new Date(nu); later.setFullYear(later.getFullYear() + 2);
    const from = datumTijd(url.searchParams.get("from"), nu);
    const to = datumTijd(url.searchParams.get("to"), later).replace("00:00", "23:59");
    const events: unknown[] = [];
    for (let page = 0; page < 20; page++) {
      const data = await planyo("list_reservations", {
        start_time: from,
        end_time: to,
        detail_level: "7",
        page: String(page)
      });
      const rows = Array.isArray(data.results) ? data.results : [];
      events.push(...rows.map((row) => eventVanReservering(row as Record<string, unknown>)));
      if (rows.length < 500) break;
    }
    return json({ events, source: "Planyo", fetchedAt: new Date().toISOString() });
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : "Onbekende fout." }, 502);
  }
});
